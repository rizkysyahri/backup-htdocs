<h3>Form Input Kompetensi Keahlian</h3>

<form action="kompetensi_input.php" method="POST">
    Nama Kompetensi Keahlian Baru :
    <input type="text" name="nm_kompetensi"> <br>
    <input type="submit" value="Masukkan"> 
</form>