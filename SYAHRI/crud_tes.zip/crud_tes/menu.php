<a href="siswa_show.php">Beranda</a>
<a href="siswa_show.php">Siswa</a>
<a href="rombel.php">Rombel</a>
<a href="kompetensi_show.php">Kompetensi Keahlian</a>
<a href="semua.php">Semua</a>
